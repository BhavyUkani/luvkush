module.exports = {
  apps: [
    {
      name: 'luvkush-backend',
      script: './backend/dist/server.js',
      cwd: '/var/www/luvkush',
      env: {
        NODE_ENV: 'production',
        PORT: 5000
      }
    },
    {
      name: 'luvkush-frontend',
      script: './frontend/dist/luvkush-natural/server/server.mjs',
      cwd: '/var/www/luvkush',
      env: {
        PORT: 4000,
        NODE_ENV: 'production'
      }
    }
  ]
};
